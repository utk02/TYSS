package com.te.flight.entity;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
public class Flight {
	@Id
	private String flightId;

	private String origin;
	private String destination;
	private LocalDateTime departure;
	private LocalDateTime arrival;
	private String journeyTime;
	private Integer totalSeats;
	private Integer bookedSeats;
	private Integer availableSeats;
	private BigDecimal price;
	

}

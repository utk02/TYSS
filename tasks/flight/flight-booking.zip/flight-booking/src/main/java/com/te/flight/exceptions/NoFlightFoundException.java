package com.te.flight.exceptions;

public class NoFlightFoundException extends RuntimeException {

	public NoFlightFoundException(String message) {
		super(message);
	}

}
